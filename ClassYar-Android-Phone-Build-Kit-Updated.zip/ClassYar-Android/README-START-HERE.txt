ClassYar Android 4.1 — Android file bridge repair

This ZIP contains a complete Gradle project source, not a prebuilt APK.

Important:
- The app HTML is based on the supplied ClassYar 4.1 HTML.
- The Android activity keeps the earlier, simpler WebView startup path; the later fullscreen/insets startup changes were intentionally not carried over.
- The Android bridge adds SAF directory listing/reading/writing and routes Blob downloads through Android's Create Document picker.
- Quick-backup directory persistence stores a serializable Android folder URI and reconstructs its handle after app restart.
- The quick-backup sequence matcher now matches CLASSYAR<n>_(YYYY-MM-DD).json, which is the filename pattern the app actually creates.
- Cloud storage implementation and unrelated HTML features were not intentionally changed.

GitHub phone workflow:
1. Upload this ZIP to the repository root using the exact name:
   ClassYar-Android-File-Bridge-Repair.zip
2. Keep the repository's root workflow file that extracts this ZIP and runs:
   working-directory: ClassYar-Android
   gradle assembleDebug
3. In GitHub Actions, run the workflow and download the artifact named ClassYar-Android-APK.

Verification:
- ZIP integrity, source HTML identity, required patch landmarks and JavaScript syntax are checked during packaging.
- This environment does not have Gradle installed, so a local Gradle/Kotlin build was not run.
- No physical Android 13 Xiaomi device is available here. Therefore app launch, quick backup, PDF and Excel must still be tested on the phone after installing the generated APK. This package is not represented as a guaranteed device-tested build.
