(function () {
  'use strict';
  if (!window.ClassYarAndroid) return;

  let seq = 0;
  const pending = new Map();

  window.__classYarNativeResult = function (id, result) {
    const p = pending.get(id);
    if (!p) return;
    pending.delete(id);
    if (!result || !result.ok) {
      const e = new Error(result && result.error || 'عملیات فایل انجام نشد');
      e.name = 'AbortError';
      p.reject(e);
    } else {
      p.resolve(result);
    }
  };

  function call(method, ...args) {
    return new Promise((resolve, reject) => {
      const id = 'cy' + (++seq);
      pending.set(id, { resolve, reject });
      try {
        const fn = window.ClassYarAndroid && window.ClassYarAndroid[method];
        if (typeof fn !== 'function') throw new Error('متد اندروید موجود نیست: ' + method);
        fn.call(window.ClassYarAndroid, id, ...args);
      } catch (e) {
        pending.delete(id);
        reject(e);
      }
    });
  }

  function fromB64(s) {
    const raw = atob(s || '');
    const out = new Uint8Array(raw.length);
    for (let i = 0; i < raw.length; i++) out[i] = raw.charCodeAt(i);
    return out;
  }

  function toB64(buffer) {
    const bytes = buffer instanceof Uint8Array ? buffer : new Uint8Array(buffer);
    let binary = '';
    const chunk = 0x8000;
    for (let i = 0; i < bytes.length; i += chunk) {
      binary += String.fromCharCode.apply(null, bytes.subarray(i, i + chunk));
    }
    return btoa(binary);
  }

  function openHandle(info) {
    return {
      name: info.name,
      kind: 'file',
      async getFile() {
        return new File([fromB64(info.data)], info.name, {
          type: info.mime || 'application/octet-stream',
          lastModified: Date.now()
        });
      }
    };
  }

  if (typeof window.showOpenFilePicker !== 'function') {
    window.showOpenFilePicker = async function (options) {
      const accept = options && options.types && options.types[0] && options.types[0].accept;
      const mime = accept ? Object.keys(accept)[0] : '*/*';
      return [openHandle(await call('openFile', mime))];
    };
  }

  if (typeof window.showSaveFilePicker !== 'function') {
    window.showSaveFilePicker = async function (options) {
      const opts = options || {};
      const accept = opts.types && opts.types[0] && opts.types[0].accept;
      const mime = accept ? (Object.keys(accept)[0] || 'application/octet-stream') : 'application/octet-stream';
      const ext = accept && accept[mime] && accept[mime][0];
      const name = opts.suggestedName || ('classyar-backup' + (ext || '.json'));
      return {
        name,
        kind: 'file',
        async createWritable() {
          let chunks = [];
          return {
            async write(data) {
              if (data instanceof Blob) chunks.push(await data.arrayBuffer());
              else if (typeof data === 'string') chunks.push(new TextEncoder().encode(data).buffer);
              else if (data instanceof ArrayBuffer) chunks.push(data);
              else if (ArrayBuffer.isView(data)) chunks.push(data.buffer.slice(data.byteOffset, data.byteOffset + data.byteLength));
              else throw new TypeError('نوع داده برای ذخیره پشتیبانی نمی‌شود');
            },
            async close() {
              const blob = new Blob(chunks, { type: mime });
              await call('saveFile', name, mime, toB64(await blob.arrayBuffer()));
              chunks = [];
            },
            async abort() { chunks = []; }
          };
        }
      };
    };
  }

  function directoryHandle(uri) {
    return {
      __cyNativeDirectory: uri,
      name: 'کلاس‌یار',
      kind: 'directory',
      async queryPermission() { return 'granted'; },
      async requestPermission() { return 'granted'; },
      async *entries() {
        const result = await call('listTreeFiles', uri);
        const names = (result.names || []).filter(Boolean).sort();
        for (const name of names) yield [name, this.getFileHandle(name)];
      },
      async getFileHandle(name) {
        return {
          name,
          kind: 'file',
          async getFile() {
            const result = await call('readTreeFile', uri, name);
            return new File([fromB64(result.data)], name, {
              type: result.mime || 'application/octet-stream',
              lastModified: Date.now()
            });
          },
          async createWritable() {
            let chunks = [];
            return {
              async write(data) {
                if (data instanceof Blob) chunks.push(await data.arrayBuffer());
                else if (typeof data === 'string') chunks.push(new TextEncoder().encode(data).buffer);
                else if (data instanceof ArrayBuffer) chunks.push(data);
                else if (ArrayBuffer.isView(data)) chunks.push(data.buffer.slice(data.byteOffset, data.byteOffset + data.byteLength));
                else throw new TypeError('نوع داده برای ذخیره پشتیبانی نمی‌شود');
              },
              async close() {
                const blob = new Blob(chunks, { type: 'application/json' });
                await call('writeTreeFile', uri, name, blob.type, toB64(await blob.arrayBuffer()));
                chunks = [];
              },
              async abort() { chunks = []; }
            };
          }
        };
      }
    };
  }

  window.classYarAndroidRestoreDirectory = function (uri) {
    return directoryHandle(uri);
  };

  window.classYarAndroidDownloadBlob = async function (name, blob) {
    const lower = String(name || '').toLowerCase();
    let mime = blob && blob.type || '';
    if (!mime || mime === 'application/octet-stream') {
      if (lower.endsWith('.pdf')) mime = 'application/pdf';
      else if (lower.endsWith('.xlsx')) mime = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';
      else if (lower.endsWith('.xls')) mime = 'application/vnd.ms-excel';
      else if (lower.endsWith('.json')) mime = 'application/json';
      else mime = 'application/octet-stream';
    }
    await call('saveFile', name || 'download', mime, toB64(await blob.arrayBuffer()));
  };

  if (typeof window.showDirectoryPicker !== 'function') {
    window.showDirectoryPicker = async function () {
      const result = await call('chooseDirectory');
      return directoryHandle(result.uri);
    };
  }
})();
