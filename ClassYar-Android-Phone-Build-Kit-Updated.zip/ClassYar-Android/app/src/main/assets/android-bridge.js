(function () {
  if (!window.ClassYarAndroid) return;
  let seq = 0;
  const pending = new Map();
  window.__classYarNativeResult = function (id, result) {
    const p = pending.get(id); if (!p) return; pending.delete(id);
    if (!result || !result.ok) { const e = new Error(result && result.error || 'عملیات فایل انجام نشد'); e.name = 'AbortError'; p.reject(e); }
    else p.resolve(result);
  };
  function call(method, ...args) {
    return new Promise((resolve, reject) => {
      const id = 'cy' + (++seq);
      pending.set(id, { resolve, reject });
      try { window.ClassYarAndroid[method](id, ...args); }
      catch (e) { pending.delete(id); reject(e); }
    });
  }
  function fromB64(s) {
    const raw = atob(s || ''); const out = new Uint8Array(raw.length);
    for (let i = 0; i < raw.length; i++) out[i] = raw.charCodeAt(i);
    return out;
  }
  function toB64(buffer) {
    const bytes = new Uint8Array(buffer); let binary = '';
    const chunk = 0x8000;
    for (let i = 0; i < bytes.length; i += chunk) binary += String.fromCharCode.apply(null, bytes.subarray(i, i + chunk));
    return btoa(binary);
  }
  function openHandle(info) {
    return {
      name: info.name,
      kind: 'file',
      async getFile() { return new File([fromB64(info.data)], info.name, { type: info.mime || 'application/octet-stream', lastModified: Date.now() }); }
    };
  }
  if (typeof window.showOpenFilePicker !== 'function') {
    window.showOpenFilePicker = async function (options) {
      const accept = options && options.types && options.types[0] && options.types[0].accept;
      const mime = accept ? Object.keys(accept)[0] : '*/*';
      return [openHandle(await call('openFile', mime))];
    };
  }
  if (typeof window.showSaveFilePicker !== 'function') {
    window.showSaveFilePicker = async function (options) {
      const opts = options || {}; const type = opts.types && opts.types[0] && opts.types[0].accept;
      const mime = type ? Object.keys(type)[0] : 'application/octet-stream';
      const ext = type && type[mime] && type[mime][0];
      const name = opts.suggestedName || ('classyar-backup' + (ext || '.json'));
      return {
        name, kind: 'file',
        async createWritable() {
          let chunks = [];
          return {
            async write(data) { if (data instanceof Blob) chunks.push(await data.arrayBuffer()); else if (typeof data === 'string') chunks.push(new TextEncoder().encode(data).buffer); else if (data && data.buffer) chunks.push(data.buffer); else throw new TypeError('نوع داده برای ذخیره پشتیبانی نمی‌شود'); },
            async close() {
              const blob = new Blob(chunks, { type: mime });
              await call('saveFile', name, mime, toB64(await blob.arrayBuffer()));
              chunks = [];
            }, async abort() { chunks = []; }
          };
        }
      };
    };
  }
  function directoryHandle(uri) {
    return {
      __cyNativeDirectory: uri, name: 'کلاس‌یار', kind: 'directory',
      async queryPermission() { return 'granted'; },
      async requestPermission() { return 'granted'; },
      async *entries() {
        const r = await call('listTreeFiles', uri);
        for (const name of (r.names || [])) yield [name, await this.getFileHandle(name)];
      },
      async getFileHandle(name) {
        return {
          name, kind: 'file',
          async getFile() { const r = await call('readTreeFile', uri, name); return new File([fromB64(r.data)], name, { type: r.mime || 'application/octet-stream', lastModified: Date.now() }); },
          async createWritable() {
            let chunks = [];
            return {
              async write(data) { if (data instanceof Blob) chunks.push(await data.arrayBuffer()); else if (typeof data === 'string') chunks.push(new TextEncoder().encode(data).buffer); else if (data && data.buffer) chunks.push(data.buffer); else throw new TypeError('نوع داده پشتیبانی نمی‌شود'); },
              async close() { const blob = new Blob(chunks); await call('writeTreeFile', uri, name, blob.type || 'application/json', toB64(await blob.arrayBuffer())); chunks = []; },
              async abort() { chunks = []; }
            };
          }
        };
      }
    };
  }
  // Route Blob downloads (PDF, Excel and JSON backups) through Android's document picker.
  window.classYarAndroidDownloadBlob = async function(name, blob) {
    const mime = blob && blob.type || 'application/octet-stream';
    await call('saveFile', name || 'download', mime, toB64(await blob.arrayBuffer()));
  };
  if (typeof window.showDirectoryPicker !== 'function') {
    window.showDirectoryPicker = async function () { const r = await call('chooseDirectory'); return directoryHandle(r.uri); };
  }
  // Store only the persistable Android folder URI in IndexedDB; rebuild its methods when read.
  try {
    const put = IDBObjectStore.prototype.put;
    IDBObjectStore.prototype.put = function (value, key) {
      if (value && value.__cyNativeDirectory) value = { __cyNativeDirectory: value.__cyNativeDirectory };
      return arguments.length > 1 ? put.call(this, value, key) : put.call(this, value);
    };
    const add = IDBObjectStore.prototype.add;
    IDBObjectStore.prototype.add = function (value, key) {
      if (value && value.__cyNativeDirectory) value = { __cyNativeDirectory: value.__cyNativeDirectory };
      return arguments.length > 1 ? add.call(this, value, key) : add.call(this, value);
    };
    const d = Object.getOwnPropertyDescriptor(IDBRequest.prototype, 'result');
    if (d && d.get && d.configurable) Object.defineProperty(IDBRequest.prototype, 'result', { configurable: true, get() { const v = d.get.call(this); return v && v.__cyNativeDirectory ? directoryHandle(v.__cyNativeDirectory) : v; } });
  } catch (_) {}
})();
