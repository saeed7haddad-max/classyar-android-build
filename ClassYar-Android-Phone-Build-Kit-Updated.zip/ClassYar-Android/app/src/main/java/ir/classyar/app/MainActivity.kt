package ir.classyar.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Build
import android.view.View
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.provider.OpenableColumns
import android.util.Base64
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.app.Activity
import androidx.documentfile.provider.DocumentFile
import org.json.JSONObject
import java.io.ByteArrayOutputStream

class MainActivity : Activity() {
    private lateinit var web: WebView
    private var fileChooserCallback: ValueCallback<Array<Uri>>? = null
    private var pendingOpenId: String? = null
    private var pendingSave: Triple<String, String, ByteArray>? = null
    private var pendingDirectoryId: String? = null

    companion object {
        private const val REQ_OPEN = 7101
        private const val REQ_SAVE = 7102
        private const val REQ_TREE = 7103
        private const val REQ_WEB_FILE = 7104
    }

    private fun enableImmersiveFullscreen() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            window.setDecorFitsSystemWindows(false)
            window.insetsController?.let { controller ->
                controller.hide(WindowInsets.Type.statusBars() or WindowInsets.Type.navigationBars())
                controller.systemBarsBehavior = WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            }
        } else {
            @Suppress("DEPRECATION")
            window.decorView.systemUiVisibility = (
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                    or View.SYSTEM_UI_FLAG_FULLSCREEN
                    or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                    or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                    or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                    or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                )
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableImmersiveFullscreen()
        web = WebView(this)
        setContentView(web)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.databaseEnabled = true
        web.settings.allowFileAccess = true
        web.settings.allowContentAccess = true
        web.settings.javaScriptCanOpenWindowsAutomatically = true
        web.settings.setSupportMultipleWindows(false)
        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val url = request?.url ?: return false
                return if (url.scheme == "http" || url.scheme == "https") {
                    if (url.host == "localhost" || url.host == "127.0.0.1") false else {
                        try { startActivity(Intent(Intent.ACTION_VIEW, url)) } catch (_: Exception) {}
                        true
                    }
                } else false
            }
        }
        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(v: WebView?, callback: ValueCallback<Array<Uri>>?, params: FileChooserParams?): Boolean {
                fileChooserCallback?.onReceiveValue(null)
                fileChooserCallback = callback
                val intent = params?.createIntent() ?: Intent(Intent.ACTION_GET_CONTENT).apply { type = "*/*" }
                intent.addCategory(Intent.CATEGORY_OPENABLE)
                return try { startActivityForResult(intent, REQ_WEB_FILE); true } catch (_: Exception) { fileChooserCallback = null; false }
            }
        }
        web.addJavascriptInterface(AndroidFiles(), "ClassYarAndroid")
        web.loadUrl("file:///android_asset/index.html")
    }

    private fun jsResult(id: String, payload: JSONObject) {
        val idJson = JSONObject.quote(id)
        val payloadJson = payload.toString()
        runOnUiThread { web.evaluateJavascript("window.__classYarNativeResult && window.__classYarNativeResult($idJson,$payloadJson)", null) }
    }

    private fun error(id: String, message: String) = jsResult(id, JSONObject().put("ok", false).put("error", message))

    private fun displayName(uri: Uri): String {
        var name = "backup.json"
        contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) name = c.getString(0) ?: name
        }
        return name
    }

    private fun readUri(uri: Uri): ByteArray = contentResolver.openInputStream(uri)?.use { input ->
        val out = ByteArrayOutputStream(); val buffer = ByteArray(8192)
        while (true) { val n = input.read(buffer); if (n < 0) break; out.write(buffer, 0, n) }
        out.toByteArray()
    } ?: ByteArray(0)

    private inner class AndroidFiles {
        @JavascriptInterface fun openFile(id: String, mime: String) {
            pendingOpenId = id
            runOnUiThread {
                val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = if (mime.isBlank()) "*/*" else mime }
                try { startActivityForResult(i, REQ_OPEN) } catch (e: Exception) { pendingOpenId = null; error(id, e.message ?: "انتخاب فایل ممکن نشد") }
            }
        }
        @JavascriptInterface fun saveFile(id: String, name: String, mime: String, base64: String) {
            pendingSave = Triple(id, mime.ifBlank { "application/octet-stream" }, try { Base64.decode(base64, Base64.DEFAULT) } catch (_: Exception) { ByteArray(0) })
            runOnUiThread {
                val i = Intent(Intent.ACTION_CREATE_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = mime.ifBlank { "application/octet-stream" }; putExtra(Intent.EXTRA_TITLE, name) }
                try { startActivityForResult(i, REQ_SAVE) } catch (e: Exception) { pendingSave = null; error(id, e.message ?: "ذخیره فایل ممکن نشد") }
            }
        }
        @JavascriptInterface fun chooseDirectory(id: String) {
            pendingDirectoryId = id
            runOnUiThread {
                try { startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT_TREE), REQ_TREE) }
                catch (e: Exception) { pendingDirectoryId = null; error(id, e.message ?: "انتخاب پوشه ممکن نشد") }
            }
        }
        @JavascriptInterface fun listTreeFiles(id: String, tree: String) {
            try {
                val root = DocumentFile.fromTreeUri(this@MainActivity, Uri.parse(tree)) ?: throw Exception("پوشه در دسترس نیست")
                val names = org.json.JSONArray()
                root.listFiles().filter { it.isFile }.forEach { names.put(it.name ?: "") }
                jsResult(id, JSONObject().put("ok", true).put("names", names))
            } catch (e: Exception) { error(id, e.message ?: "خواندن فهرست پوشه ناموفق بود") }
        }
        @JavascriptInterface fun readTreeFile(id: String, tree: String, name: String) {
            try {
                val root = DocumentFile.fromTreeUri(this@MainActivity, Uri.parse(tree)) ?: throw Exception("پوشه در دسترس نیست")
                val file = root.findFile(name) ?: throw Exception("فایل ذخیره‌شده پیدا نشد")
                val bytes = readUri(file.uri)
                jsResult(id, JSONObject().put("ok", true).put("name", name).put("mime", file.type ?: "application/octet-stream").put("data", Base64.encodeToString(bytes, Base64.NO_WRAP)))
            } catch (e: Exception) { error(id, e.message ?: "خواندن فایل ناموفق بود") }
        }
        @JavascriptInterface fun writeTreeFile(id: String, tree: String, name: String, mime: String, base64: String) {
            try {
                val root = DocumentFile.fromTreeUri(this@MainActivity, Uri.parse(tree)) ?: throw Exception("پوشه در دسترس نیست")
                val existing = root.findFile(name); existing?.delete()
                val file = root.createFile(mime.ifBlank { "application/octet-stream" }, name) ?: throw Exception("ساخت فایل ممکن نشد")
                val bytes = Base64.decode(base64, Base64.DEFAULT)
                contentResolver.openOutputStream(file.uri, "w")?.use { it.write(bytes); it.flush() } ?: throw Exception("نوشتن فایل ممکن نشد")
                jsResult(id, JSONObject().put("ok", true))
            } catch (e: Exception) { error(id, e.message ?: "نوشتن در پوشه ناموفق بود") }
        }
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) enableImmersiveFullscreen()
    }

    @Deprecated("Deprecated in Android")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        when (requestCode) {
            REQ_OPEN -> {
                val id = pendingOpenId; pendingOpenId = null
                if (id != null) {
                    if (resultCode == Activity.RESULT_OK && data?.data != null) try {
                        val uri = data.data!!; val bytes = readUri(uri)
                        val p = JSONObject().put("ok", true).put("name", displayName(uri)).put("mime", contentResolver.getType(uri) ?: "application/octet-stream").put("data", Base64.encodeToString(bytes, Base64.NO_WRAP))
                        jsResult(id, p)
                    } catch (e: Exception) { error(id, e.message ?: "خواندن فایل ممکن نشد") }
                    else error(id, "انتخاب فایل لغو شد")
                }
            }
            REQ_SAVE -> {
                val pending = pendingSave; pendingSave = null
                if (pending != null) {
                    val (id, _, bytes) = pending
                    if (resultCode == Activity.RESULT_OK && data?.data != null) try {
                        contentResolver.openOutputStream(data.data!!, "w")?.use { it.write(bytes); it.flush() } ?: throw Exception("ذخیره فایل ناموفق بود")
                        jsResult(id, JSONObject().put("ok", true))
                    } catch (e: Exception) { error(id, e.message ?: "ذخیره فایل ناموفق بود") }
                    else error(id, "ذخیره فایل لغو شد")
                }
            }
            REQ_TREE -> {
                val id = pendingDirectoryId; pendingDirectoryId = null
                if (id != null) {
                    if (resultCode == Activity.RESULT_OK && data?.data != null) {
                        val uri = data.data!!
                        try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION) } catch (_: Exception) {}
                        jsResult(id, JSONObject().put("ok", true).put("uri", uri.toString()))
                    } else error(id, "انتخاب پوشه لغو شد")
                }
            }
            REQ_WEB_FILE -> {
                val cb = fileChooserCallback; fileChooserCallback = null
                cb?.onReceiveValue(if (resultCode == Activity.RESULT_OK) WebChromeClient.FileChooserParams.parseResult(resultCode, data) else null)
            }
        }
    }

    override fun onBackPressed() {
        if (::web.isInitialized && web.canGoBack()) web.goBack() else super.onBackPressed()
    }
}
